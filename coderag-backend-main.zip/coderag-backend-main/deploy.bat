@echo off
REM ============================================================
REM  CodeRAG Backend - Azure Deployment Script
REM  Run this from the coderag-backend directory
REM ============================================================

set RG=CodeRAG-Group
set APP=coderag-backend-shyam
set LOCATION=centralindia
set RUNTIME=PYTHON:3.12
set STARTUP_CMD=gunicorn --bind=0.0.0.0:8000 -w 2 -k uvicorn.workers.UvicornWorker main:app

echo.
echo [1/4] Deploying code to Azure...
call az webapp up --name %APP% --resource-group %RG% --location %LOCATION% --runtime "%RUNTIME%"
if %errorlevel% neq 0 (
    echo DEPLOY FAILED. Exiting.
    exit /b 1
)

echo.
echo [2/4] Setting startup command...
call az webapp config set --resource-group %RG% --name %APP% --startup-file "%STARTUP_CMD%"

echo.
echo [3/4] Setting environment variables...
REM Set your GEMINI_API_KEY and OpenAI keys in Azure App Settings
call az webapp config appsettings set --resource-group %RG% --name %APP% --settings SCM_DO_BUILD_DURING_DEPLOYMENT=true

echo.
echo [4/4] Restarting app...
call az webapp restart --resource-group %RG% --name %APP%

echo.
echo ============================================================
echo  DEPLOYMENT COMPLETE!
echo  URL: https://%APP%-dufsctg9hva6f2ez.centralindia-01.azurewebsites.net
echo  Health: https://%APP%-dufsctg9hva6f2ez.centralindia-01.azurewebsites.net/health
echo ============================================================
